#' Worldwide Governance Indicators
#'
#' Data about the Worldwide Governance Indicators in 214 countries from 1996 to 2016.
#'
#' @format A tibble with 3852 observations and 10 variables:
#' \itemize{
#'   \item ID. A character string indicating the country (ISO3 code) and the year.
#'   \item Country. Factor indicating the country (ISO3 code).
#'   \item year. Integer indicating the year.
#'   \item Control_of_corruption. Numeric. Score the World Bank granted the country for this year on the indicator control of corruption.
#'   \item Government_effectiveness. Numeric. Score the World Bank granted the country for this year on the indicator government effectiveness.
#'   \item Political_stability_and_absence_of_violence_terrorism. Numeric. Score the World Bank granted the country for this year on the indicator Political stability and absence of violence terrorism.
#'   \item Rule_of_law. Numeric. Score the World Bank granted the country for this year on the indicator Rule of law.
#'   \item Regulatory_quality. Numeric. Score the World Bank granted the country for this year on the indicator Regulatory quality.
#'   \item Voice_and_accountability. Numeric. Score the World Bank granted the country for this year on the indicator Voice and accountability.
#'   \item mean_WGI. Numeric. Average score for each country-year across all six previously mentioned indicators.
#'     
#' }
#' @source \url{https://datacatalog.worldbank.org/dataset/worldwide-governance-indicators}
#' @docType data
#' @keywords WGI, Worldwide Governance Indicators
#' @name WGI
#' @usage data("WGI")
#' @references {Worldwide Governance Indicators (www.govindicators.org)}
"WGI"
