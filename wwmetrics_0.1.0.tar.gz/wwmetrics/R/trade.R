#' Trade
#'
#' Data on bilateral trade from [CEPII]{http://www.cepii.fr/CEPII/en/welcome.asp} from 2001 to 2014. Given that most observations in this database report imports and not exports (429 765 vs 20 117 respectively), import data was transformed into export data to be subsequently included in the statistical analyses: if France imports $5m of products and services from Poland, it is equivalent to say that Poland exports $5m to France, so for imports FRA-POL=$5m and for exports POL-FRA=$5m. 
#' 
#' @format A tibble with 393 068 observations and 7 variables:
#' \itemize{
#'   \item ID. Factor indicating the countries forming each country pair (ISO3 code) and the year.
#'   \item year. Integer indicating the year.
#'   \item CountryPair. Factor indicating the country pair (ISO3 code).
#'   \item origin. Factor indicating the first country (ISO3 code) of the country pair.
#'   \item destination. Factor indicating the second country (ISO3 code) of the country pair.
#'   \item imports. Numeric. Indicates the amount of imports to the origin country from the destination country (log).
#'   \item exports. Numeric. Indicates the amount of exports from the origin country to the destination country (log).
#'  }
#' @source \url{http://www.cepii.fr/CEPII/en/bdd_modele/presentation.asp?id=32}
#' @docType data
#' @keywords trade, imports, exports
#' @name trade
#' @usage data("trade")
#' @references {Two Centuries of Bilateral Trade and Gravity Data: 1827-2014. CEPII Working Paper, N°2016-14, mai 2016 Michel Fouquin, Jules Hugot}
"trade"
